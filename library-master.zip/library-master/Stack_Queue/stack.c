#include "stack.h"


Stack new_Stack(){
	return new_dllist();
}

int isEmptyStack(Stack s){
	return dll_empty(s);
}

void push(Stack s, Jval v){
	dll_prepend(s, v); 
}

Jval pop(Stack s){
	Stack node = s->flink;
	Jval value = node->val;
	dll_delete_node(node);

	return value;
}

