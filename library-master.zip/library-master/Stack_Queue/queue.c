#include "queue.h"


Queue new_Queue(){
	return new_dllist(); 
}

int isEmptyQueue(Queue q){
	return dll_empty(q);
}

void enQueue(Queue q, Jval v){
	dll_prepend(q, v); 
}

Jval deQueue(Queue q){
	Queue node = q->blink;
	Jval value = node->val;

	dll_delete_node(node);

	return value;
}