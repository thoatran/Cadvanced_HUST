#include <stdio.h>
#include "./libfdr/jrb.h"
#include "undirected_graph/undirected_graph.h"
#include <string.h>
#include <stdlib.h>


void MENU(){
	printf("\tMENU\n");
	printf("1. \n");
	printf("2. \n");
	printf("3. \n");
	printf("4. \n");
	printf("5. \n");
	printf("6. EXIT\n");
}

int	main(int argc, char const *argv[]){
	if(argc != 3){
		printf("There should be 3 arguments:\n");
		printf("1. Executed File\n");
		printf("2. \n");
		printf("3. \n");

		return 0;
	}

	char* file1 = argv[1];
	char* file2 = argv[2];
	FILE* f1;
	FILE* f2;

	if((f1 = fopen(file1, "r")) == NULL){
		printf("%s does not existed!\n", file1);
		return 0;
	}

	if((f2 = fopen(file2, "r")) == NULL){
		printf("%s does not existed!\n", file2);
		return 0;
	}


	int choice;

	do{

		MENU();
		printf("\nChoice: ");
		
		while(scanf("%d", &choice) != 1){			
			getchar();
			printf("Choice should be integer!\n\n");			
			MENU();
			printf("\nChoice: ");
			
		}

		switch (choice){
			case 1:
				break;
			
			case 2:
				break;
			
			case 3:
				break;
		
			case 4:
				break;
			
			case 5:
				break;
			
			case 6:
				break;

			default:
				printf("Invalid value for choice: %d\n\n", choice);
				break;
		}


	}while(choice != 6);


	fclose(f1);
	fclose(f2);

	return 0;
}