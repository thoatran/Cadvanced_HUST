#include "../libfdr/jrb.h"
#include "../libfdr/dllist.h"
#include "../functions/queue.h"
#include "../functions/stack.h"
#include "../functions/priority_queue_graph.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>


typedef struct{
	JRB edges;
	JRB vertices;
}Graph;

Graph createGraph();
int addVertex(Graph graph, int id, Jval value);
Jval getVertex(Graph graph, int id);
int getAdjacentVertices (Graph graph, int id, int* output); 
void addEdge(Graph graph, int v1, int v2, double weight);
int hasEdge(Graph graph, int v1, int v2);
void dropGraph(Graph graph);

double getEdgeWeight(Graph graph, int v1, int v2);
void changeEdgeWeight(Graph graph, int v1, int v2, double newWeight);
double shortestPath(Graph graph, int s, int t, int* path, int* length);
void BFS(Graph g, int start, int end, void (*func)(Graph, int));
void DFS(Graph g, int start, int end, void (*func)(Graph, int));

void deleteEdge(Graph graph, int v1, int v2);
void deleteVertex(Graph graph, int id);

int hasVertex(Graph graph, int id);