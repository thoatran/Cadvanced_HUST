#include "../libfdr/dllist.h"

typedef Dllist Stack;

extern Stack new_Stack();
extern int isEmptyStack(Stack);
extern void push(Stack, Jval);
extern Jval pop(Stack);

