#include "priority_queue_graph.h"

Queue new_PriQueue(){
	return new_dllist(); 
}

int isEmptyPriQueue(Queue q){
	return dll_empty(q);
}

void enPriQueue(Queue q, Jval v){ //v is JRB
	dll_prepend(q, v);
}

Jval dePriQueue(Queue q){

	double min = ((vertexInfo*)(q->flink->val.v))->weight;
	Dllist min_ptr = q->flink;

	for(Dllist ptr = q->flink; ptr != q; ptr = ptr->flink){
		if(min > ((vertexInfo*)(ptr->val.v))->weight){
			min = ((vertexInfo*)(ptr->val.v))->weight;
			min_ptr = ptr;
		}
	}
	Jval value = min_ptr->val;
	dll_delete_node(min_ptr);

	return value;
}