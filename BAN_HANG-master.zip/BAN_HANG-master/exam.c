#include <stdio.h>
#include "./libfdr/jrb.h"
#include "undirected_graph/undirected_graph.h"
#include <string.h>
#include <stdlib.h>


void MENU(){
	printf("\tMENU\n");
	printf("1. DANH SACH SAN PHAM\n");
	printf("2. DANH SACH GIAO DICH\n");
	printf("3. MUC DO LIEN QUAN GIUA 2 SAN PHAM\n");
	printf("4. DANH SACH SAN PHAM LIEN QUAN\n");
	printf("5. MOI LIEN HE GIUA 2 SAN PHAM\n");
	printf("6. EXIT\n");
}

void readProducts(FILE* f, Graph productGraph){
	int id;
	char product[256];
	char c;

	while(fscanf(f, "%d %s", &id, product) != EOF){
		addVertex(productGraph, id, new_jval_s(strdup(product)));
	}
}

void makeRelation(Graph productGraph, int array[], int n){
	for(int i = 0; i < n - 1; i ++){
		for(int j = i + 1; j < n; j++)
			if(hasEdge(productGraph, array[i], array[j]) == 1)
				changeEdgeWeight(productGraph, array[i], array[j], getEdgeWeight(productGraph, array[i], array[j]) + 1.0);
			else 
				addEdge(productGraph, array[i], array[j], 1.0);
	}
}

void readOrderHistory(FILE* f, Graph productGraph){
	int id;
	int array[100];
	int c;
	int i = 0;
	char buffer[256];
	int j = 0;

	do{
		c = fgetc(f);
		if(c == '\n' || c == EOF){
			id = atoi(buffer);
			array[i++] = id;
			makeRelation(productGraph, array, i);
			i = 0;
			j = 0;
			buffer[0] = '\0';
			printf("%s\n", getVertex(productGraph, id).s);
		}
		else if (c == ' '){
			id = atoi(buffer);
			array[i++] = id;
			j = 0;
			buffer[0] = '\0';
			printf("%s ", getVertex(productGraph, id).s);
		}
		else{
			buffer[j++] = c;
			buffer[j] = '\0';
		}
	}while(c != EOF);
	printf("\n");
}

void hasRelationship(Graph productGraph){
	int id1;
	int id2;

	printf("ID San Pham 1: ");
	scanf("%d", &id1);
	getchar();

	printf("ID San Pham 2: ");
	scanf("%d", &id2);
	getchar();

	if(!hasEdge(productGraph, id1, id2)){
		printf("-1\n\n");
	}
	else printf("Do lien quan giua %s va %s: %.0f\n\n", getVertex(productGraph, id1).s, getVertex(productGraph, id2).s, getEdgeWeight(productGraph, id1, id2));
}

void RelativeProducts(Graph productGraph){
	int id;

	printf("ID San Pham: ");
	scanf("%d", &id);
	getchar();	

	if(getVertex(productGraph, id).v == NULL){
		printf("KHONG TON TAI MA SAN PHAM!\n\n");
		return;
	}

	int n;
	int output[100];

	n = getAdjacentVertices(productGraph, id, output);
	if(n == 0)
		printf("Khong co san pham nao lien quan den %s\n\n", getVertex(productGraph, id).s);
	else{
		printf("DANH SACH SAN PHAM LIEN QUAN:\n\n");
		for(int i = 0; i < n; i ++)
			printf("%-4d %s\n", i+1, getVertex(productGraph, output[i]).s);
	}
	printf("\n");
}

void relationshipOfTwoProducts(Graph productGraph){
	int id1;
	int id2;

	printf("ID San Pham 1: ");
	scanf("%d", &id1);
	getchar();

	printf("ID San Pham 2: ");
	scanf("%d", &id2);
	getchar();

	int path[100];
	int length = 0;

	if(shortestPath(productGraph, id1, id2, path, &length) > 1000000)
		printf("KHONG CO QUAN HE NAO!\n\n");
	else
		for(int i = length - 1; i >= 0 ; i --){
			if(i == 0)
				printf("%s\n\n", getVertex(productGraph, path[i]).s);
			else 
				printf("%s, ", getVertex(productGraph, path[i]).s);
		}

}

void displayProducts(Graph productGraph){
	JRB tmp = NULL;

	jrb_traverse(tmp, productGraph.vertices){
		printf("Ma san pham: %d\n", tmp->key.i);
		printf("Ten san pham: %s\n\n", tmp->val.s);
	}
}

int	main(int argc, char const *argv[]){
	if(argc != 3){
		printf("There should be 3 arguments:\n");
		printf("1. Executed File\n");
		printf("2. Products List File\n");
		printf("3. Order History File\n");

		return 0;
	}

	char* file1 = argv[1];
	char* file2 = argv[2];
	FILE* f1;
	FILE* f2;

	if((f1 = fopen(file1, "r")) == NULL){
		printf("%s does not existed!\n", file1);
		return 0;
	}

	if((f2 = fopen(file2, "r")) == NULL){
		printf("%s does not existed!\n", file2);
		return 0;
	}

	Graph productGraph = createGraph();
	readProducts(f1, productGraph);


	int choice;

	do{
		MENU();
		printf("\nChoice: ");
		scanf("%d", &choice);
		getchar();

		switch (choice){
			case 1:
				displayProducts(productGraph);
				break;
			
			case 2:
				readOrderHistory(f2, productGraph);
				break;
			
			case 3:
				hasRelationship(productGraph);
				break;
		
			case 4:
				RelativeProducts(productGraph);
				break;
			
			case 5:
				relationshipOfTwoProducts(productGraph);
				break;
			
			case 6:
				break;

			default:
				printf("Invalid value for choice: %d\n\n", choice);
				break;
		}


	}while(choice != 6);


	fclose(f1);
	fclose(f2);

	return 0;
}