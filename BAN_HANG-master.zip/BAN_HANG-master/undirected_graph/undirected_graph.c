#include "undirected_graph.h"


Graph createGraph(){
	Graph newGraph;
	newGraph.edges = make_jrb();
	newGraph.vertices = make_jrb();
	return newGraph;
}


int addVertex(Graph graph, int id, Jval value){
	if(jrb_find_int(graph.vertices, id) != NULL)
		return 0; //false

	jrb_insert_int(graph.vertices, id, value);
	return 1;
}

Jval getVertex(Graph graph, int id){
	JRB tmp = NULL;
	Jval value;
	value.v = NULL;


	jrb_traverse(tmp, graph.vertices){
		if(tmp->key.i == id)
			return tmp->val;
	}
	
	return value;
}



void addEdge(Graph graph, int v1, int v2, double weight){
	if((jrb_find_int(graph.vertices, v1) == NULL) || (jrb_find_int(graph.vertices, v1) == NULL))
		return;

	JRB Graph_v1 = NULL;
	JRB Graph_v2 = NULL;
	JRB JRB_v1 = NULL;
	JRB JRB_v2 = NULL;

	if((Graph_v1 = jrb_find_int(graph.edges, v1)) == NULL){
		JRB_v1 = make_jrb();
		jrb_insert_int(graph.edges, v1, new_jval_v((void*) JRB_v1));
		Graph_v1 = jrb_find_int(graph.edges, v1);
	}

	if((Graph_v2 = jrb_find_int(graph.edges, v2)) == NULL){
		JRB_v2 = make_jrb();
		jrb_insert_int(graph.edges, v2, new_jval_v((void*) JRB_v2));
		Graph_v2 = jrb_find_int(graph.edges, v2);
	}

	JRB_v1 = (JRB) Graph_v1->val.v;
	JRB_v2 = (JRB) Graph_v2->val.v;

	jrb_insert_int(JRB_v1, v2, new_jval_d(weight));
	jrb_insert_int(JRB_v2, v1, new_jval_d(weight));
}

int getAdjacentVertices (Graph g, int v, int* output){
	int n = 0;
	JRB graph = g.edges;
	JRB vertex_Graph = NULL;
	JRB subTree_Root = NULL;
	JRB tmp = NULL;

	if((vertex_Graph = jrb_find_int(graph, v)) == NULL) 
		return 0;

	subTree_Root = (JRB) vertex_Graph->val.v;

	jrb_traverse(tmp, subTree_Root){
		n++;
		output[n-1] = tmp->key.i;
	}

	return n;
}

int hasEdge(Graph graph, int v1, int v2){
	JRB tmp = jrb_find_int(graph.edges, v1);
	if(tmp == NULL) return 0;

	tmp = (JRB) tmp->val.v;

	if(jrb_find_int(tmp, v2) == NULL)
		return 0;

	return 1;
}


void dropGraph(Graph graph){
	jrb_free_tree(graph.edges);
	jrb_free_tree(graph.vertices);
}


void changeEdgeWeight(Graph graph, int v1, int v2, double newWeight){
	//change edge v1->v2
	JRB tmp = jrb_find_int(graph.edges, v1);
	JRB tmp1 = NULL;
	if(tmp == NULL) return;

	tmp = (JRB) tmp->val.v;

	if((tmp1 = jrb_find_int(tmp, v2)) == NULL)
		return;

	tmp1->val.d = newWeight;

	//chage edge v2->v1
	tmp = jrb_find_int(graph.edges, v2);
	tmp1 = NULL;

	tmp = (JRB) tmp->val.v;
	tmp1 = jrb_find_int(tmp, v1);
	tmp1->val.d = newWeight;	
}

double getEdgeWeight(Graph graph, int v1, int v2){
	JRB tmp = jrb_find_int(graph.edges, v1);
	JRB tmp1 = NULL;
		if(tmp == NULL) return INT_MIN * 1.0;

	tmp = (JRB) tmp->val.v;

	if((tmp1 = jrb_find_int(tmp, v2)) == NULL)
		return INT_MIN*1.0;

	return tmp1->val.d;
}

double shortestPath(Graph graph, int s, int t, int* path, int* length){
		int parent[1000]; 
		double distance[1000];
		JRB tmp = NULL;             //for jrb traverse
		int n;                      //number of Adjacent Vertices of a visiting node 
		int adjacent_Vertices[100]; //list of adjacent vertice of visiting node
		double result = 0;          //shortest distance

		//(parent[i] = -1) indicates i has no parent at the moment;
		//(distance[i] = INT_MAX*1.0) indicates there is no path from s to i at the moment
		for(int i = 0; i < 1000; i ++){
				parent[i] = -1;
				distance[i] = INT_MAX * 1.0;
		} 

		distance[s] = 0;    //s is starting vertex

		Queue q = new_PriQueue();	//priority Queue

		//enQueue all the vertice 
		jrb_traverse(tmp, graph.vertices){
				vertexInfo* new = (vertexInfo*) malloc(sizeof(vertexInfo));
		
				new->id = tmp->key.i;
				if(new->id != s)
						new->weight = INT_MAX * 1.0;
				else 
						new->weight = 0.0;
		
				enPriQueue(q, new_jval_v((void*) new));
		}

		while(!isEmptyPriQueue(q)){
				int u = ((vertexInfo*) (dePriQueue(q).v))->id; //get the vertice with smallest distance form priority queue
				
				n = getAdjacentVertices(graph, u, adjacent_Vertices); //get adjacent vertice of u
						
						for(int i = 0; i < n ; i ++){

								if(distance[adjacent_Vertices[i]] > distance[u] + getEdgeWeight(graph, u, adjacent_Vertices[i])){
										//relax
										distance[adjacent_Vertices[i]] = distance[u] + getEdgeWeight(graph, u, adjacent_Vertices[i]);
										parent[adjacent_Vertices[i]] = u;

										//modify queue
										for(Dllist ptr = q->flink; ptr != q; ptr = ptr->flink){
												if(((vertexInfo*) (ptr->val.v))->id == adjacent_Vertices[i]){
														((vertexInfo*) (ptr->val.v))->weight = distance[adjacent_Vertices[i]];

														continue;
												}
										}
								}
						}    
		}

		n = parent[t];
		if(n == -1){
				*length = 0;  
				return INT_MAX*1.0;
		}

		*length = 1;
		path[0] = t;
		n = t;
		result = 0.0;

		while(parent[n] != -1){

				result += getEdgeWeight(graph, parent[n], n);
				n = parent[n];
				(*length) ++;
				path[(*length)-1] = n; 
		}

		return result;
}



void BFS(Graph graph, int start, int end, void (*func)(Graph, int)){
	JRB g = graph.edges;
	JRB visited = make_jrb(); 		//store the visited vertices
									//empty tree indicates no node has been visited
	int n;							//number of Adjacent Vertices of a visiting node 
	int adjacent_Vertices[100];		//Adjacent Vertices of visiting node
	Queue q = new_Queue();
	enQueue(q, new_jval_i(start));
	jrb_insert_int(visited, start, new_jval_i(start));


	while(!isEmptyQueue(q)){
		int u = jval_i(deQueue(q));
		func(graph, u);			
			
		if(u == end) return;

		n = getAdjacentVertices(graph, u, adjacent_Vertices);

		for(int i = 0; i < n; i ++){
			if(jrb_find_int(visited, adjacent_Vertices[i]) == NULL){
					//func(adjacent_Vertices[i]);
					jrb_insert_int(visited, adjacent_Vertices[i], new_jval_i(adjacent_Vertices[i]));
					enQueue(q, new_jval_i(adjacent_Vertices[i]));
			}
		}				
	}
}

void DFS(Graph graph, int start, int end, void (*func)(Graph, int)){
	JRB g = graph.edges;
	JRB visited = make_jrb(); 		//store the visited vertices
									//empty tree indicates no node has been visited
	int n;							//number of Adjacent Vertices of a visiting node 
	int adjacent_Vertices[100];		//Adjacent Vertices of visiting node
	Stack s = new_Stack();
	push(s, new_jval_i(start));
	jrb_insert_int(visited, start, new_jval_i(start));
	
	while(!isEmptyStack(s)){
		int u = jval_i(pop(s));
		func(graph, u);

		if(u == end) return;

		n = getAdjacentVertices(graph, u, adjacent_Vertices);

		for(int i = 0; i < n ; i ++){
			if(jrb_find_int(visited, adjacent_Vertices[i]) == NULL){
				jrb_insert_int(visited, adjacent_Vertices[i], new_jval_i(adjacent_Vertices[i]));
				push(s, new_jval_i(adjacent_Vertices[i]));	
			}
		}
	}
}



