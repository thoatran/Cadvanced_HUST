#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jrb.h"
#include "jval.h"

typedef struct{
  char name[30];
  char phoneNumber[20];
}phoneContact;

void MENU(void) {
  printf("\n\tMENU\n");
  printf("1. ADD CONTACT\n");
  printf("2. DELETE CONTACT\n");
  printf("3. MODIFY CONTACT\n");
  printf("4. DISPLAY CONTACT\n");
  printf("5. EXIT\n\n");
}


phoneContact readOneContact(char* buff){
  phoneContact phone;
  int flag = 0;
  int i = 0;
  
  for(unsigned j = 0; j < strlen(buff); j++){
    if (buff[j] == '\t'){
      flag ++;
      i = 0;
    }
    else if (buff[j] == '\n');
    else{
      switch (flag){
      case 0:
	       phone.name[i++] = buff[j];
	       phone.name[i] = '\0';
	     break;

      case 1:
	       phone.phoneNumber[i++] = buff[j];
	       phone.phoneNumber[i] = '\0';	
	     break;	
      }
    }
  }
  return phone;
}

JRB readFile(FILE* f){
  JRB phoneBook = make_jrb();
  phoneContact* tmp = NULL;
  
  char buff[256];
   while((fgets(buff,256, f)) != NULL){
    phoneContact phoneBuff = readOneContact(buff);
    tmp = (phoneContact*) malloc(sizeof(phoneContact));
    strcpy(tmp->name, phoneBuff.name);
    strcpy(tmp->phoneNumber, phoneBuff.phoneNumber);
    jrb_insert_str(phoneBook, tmp->name, new_jval_v((void*) tmp));
  }
   return phoneBook;
}

void display(JRB phoneBook){
  JRB tmp;
  phoneContact* contact = NULL;
  printf("\nPhone Contact:\n\n");
  jrb_traverse(tmp, phoneBook){
    contact = (phoneContact*) tmp->val.v;
    printf("%-30s %s\n", contact->name, contact->phoneNumber);
  }
}

JRB addContact(JRB phoneBook){
  char name[30];
  char phoneNumber[20];
  JRB tmp = NULL;
  char choice;
  
  printf("\nName: ");
  scanf("%[^\n]s", name);
  getchar();
  printf("Number: ");
  scanf("%[^\n]s", phoneNumber);
  getchar();

  tmp = jrb_find_str(phoneBook, name);
  if(tmp != NULL){
    
    do{
      printf("The name has already existed!\nDo you want to continue (y/n): ");
      scanf("%c", &choice);
      getchar();

      if(choice != 'y' && choice != 'n')
	printf("Invalid value: %c\n", choice);
      
    } while(choice != 'y' && choice != 'n');

    if(choice == 'n')
      return phoneBook;
  }
  
  phoneContact* phone = (phoneContact*) malloc(sizeof(phoneContact));
  strcpy(phone->name, name);
  strcpy(phone->phoneNumber, phoneNumber);
  jrb_insert_str(phoneBook, name, new_jval_v((void*) phone));

  printf("ADDING NEW CONTACT SUCCESSFULLY!\n");
  return phoneBook;
}

JRB deleteContact(JRB phoneBook){
  char name[30];
  JRB tmp = NULL;
  
  printf("\nName: ");
  scanf("%[^\n]s", name);
  getchar();
  
  tmp = jrb_find_str(phoneBook, name);
  if(tmp != NULL){
    jrb_delete_node(tmp);
    printf("DELETING SUCCESSFULLY!\n");
  }
  else printf("The phone book does not contain any contact with name: %s\n", name);

  return phoneBook;
}


JRB modifyContact(JRB phoneBook){
  char name[30];
  char phoneNumber[20];
  JRB tmp = NULL;
  
  printf("\nName: ");
  scanf("%[^\n]s", name);
  getchar();
  
  tmp = jrb_find_str(phoneBook, name);
  if(tmp != NULL){
      
    printf("New Number: ");
    scanf("%[^\n]s", phoneNumber);
    getchar();

    phoneContact* buff = (phoneContact*) malloc(sizeof(phoneContact));
    strcpy(buff->name, name);
    strcpy(buff->phoneNumber, phoneNumber);
    
    tmp->val = new_jval_v((void*) buff);
    
    printf("MODIFYING SUCCESSFULLY!\n");
  }
  else printf("The phone book does not contain any contact with name: %s\n", name);

  return phoneBook;
}


int main(int argc, char** argv){
  if (argc != 2){
    printf("There should be 2 arguments:\n");
    printf("1. Executed file.\n");
    printf("2. Phone Contact file.\n");
    return 0;
  }

  char* file = argv[1];
  FILE* f;
  if((f = fopen(file, "r")) == NULL){
    printf("%s does not exists!\n", file);
    return 0;
  }

  int choice;
  JRB phoneBook;
  phoneBook = make_jrb();
  phoneBook = readFile(f);
  
  do{
    MENU();
    printf("Choice: ");
    scanf("%d", &choice);
    getchar();

    switch (choice) {
    case 1:   //ADD NEW CONTACT
      phoneBook = addContact(phoneBook);
      break;
    case 2:   //DELETE
      phoneBook = deleteContact(phoneBook);
      break;
    case 3:   //MODIFY
      phoneBook = modifyContact(phoneBook);
      break;
    case 4:   //DISPLAY CONTACT
      display(phoneBook);
      break;
      
    case 5:   //EXIT
      break;
      
    default:
      printf("Invalid value: %d\n", choice);
      break;
    }
    
  }while(choice != 5);

  
  jrb_free_tree(phoneBook);
  
  return 0;
}

