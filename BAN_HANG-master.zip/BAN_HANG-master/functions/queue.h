#include "../libfdr/dllist.h"

typedef Dllist Queue;

extern Queue new_Queue();
extern int isEmptyQueue(Queue);
extern void enQueue(Queue, Jval);
extern Jval deQueue(Queue);

