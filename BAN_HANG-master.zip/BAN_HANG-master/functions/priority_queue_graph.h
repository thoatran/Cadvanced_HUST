#include "../libfdr/dllist.h"
#include "../libfdr/jrb.h"


typedef Dllist Queue;
typedef struct{
		int id;
		double weight;
}vertexInfo;



extern Queue new_PriQueue();
extern int isEmptyPriQueue(Queue);
extern void enPriQueue(Queue, Jval);
extern Jval dePriQueue(Queue);

