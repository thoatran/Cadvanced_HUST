#include "../libfdr/jrb.h"
#include "../libfdr/dllist.h"
#include "../functions/queue.h"
#include "../functions/stack.h"
#include "../functions/priority_queue_graph.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>


typedef struct{
	JRB edges;
	JRB vertices;
}DirectedGraph;

DirectedGraph createGraph();
int addVertex(DirectedGraph graph, int id, Jval value);
Jval getVertex(DirectedGraph graph, int id);
int getAdjacentVertices (DirectedGraph graph, int id, int* output); 
void addEdge(DirectedGraph graph, int v1, int v2, double weight);
int hasEdge(DirectedGraph graph, int v1, int v2);
int indegree(DirectedGraph graph, int id);
int outdegree(DirectedGraph graph, int id);
int isDAG(DirectedGraph graph);
void dropGraph(DirectedGraph graph);
Dllist topoSort(DirectedGraph graph);



void changeEdgeWeight(DirectedGraph graph, int v1, int v2, double newWeight);
double getEdgeWeight(DirectedGraph graph, int v1, int v2);
double shortestPath(DirectedGraph graph, int s, int t, int* path, int* length);
void BFS(DirectedGraph g, int start, int end, void (*func)(DirectedGraph, int));
void DFS(DirectedGraph g, int start, int end, void (*func)(DirectedGraph, int));
