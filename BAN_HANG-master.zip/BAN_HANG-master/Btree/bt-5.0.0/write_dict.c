#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "btree.h"


typedef phone{
	char name[30];
	char phoneNumber[30];
}phoneContact;


phoneContact readLine(char* s){
	phoneContact phone;
	int i = 0;
	int flag = 0;

	for(int j = 0; j < strlen(s); j ++){
		if(s[j] == '\n');
		else if(s[j] == '\t'){
			flag ++;
			i = 0;
		}


		else{
			switch (flag){
				case 0:
					phone.name[i++] = s[j];
					phone.name[i] = '\0';
					break;

				case 1:
					phone.phoneNumer[i++] = s[j];
					phone.phoneNumber[i] = '\0'
					break;

				default:
				break;
			}
		}
	}

	return phoneContact;
}

void readFile(FILE* f, BTA* bt_phoneBook){
	char* s = (char*) malloc(256 * sizeof(char));
	char* name = (char*) malloc(30 * sizeof(char));
	phoneContact phone;
	while((fgets(s, 256, f)) != NULL){
		phone = readLine(s);

		printf("%30s%s\n", phone.name, phone.phoneNumber);

		btins(bt_phoneBook, strdup(phone.name), strdup(phone.phoneNumber), strlen(phone.phoneNumber) * sizeof(char));
	}
}



int main(int argc, char const *argv[])
{
	printf("BEGIN!\n");

	if(argc != 2){
		printf("3 arguments!\n");
		return 0;
	}
	char* file = argv[1];
	FILE* f;

	if((f = fopen(file, "r")) == NULL){
		printf("file does not exist!\n");
		return 0;
	}


	btinit();
	BTA* bt_phoneBook = btcrt("phoneBook", 0, 0);
	readFile(f, bt_phoneBook);

	btcls(bt_phoneBook);

	printf("DONE!\n");
	/* code */
	return 0;
}