extern int SoundEx(char *SoundEx,
		   char *WordString,
		   int   LengthOption,
		   int   CensusOption);
