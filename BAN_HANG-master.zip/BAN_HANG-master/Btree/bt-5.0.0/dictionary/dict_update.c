#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "btree.h"

void MENU(void) {
  printf("\n\tMENU\n");
  printf("1. ADD WORD\n");
  printf("2. DELETE WORD\n");
  printf("3. UPDATE WORD\n");
  printf("4. SEARCH WORD\n");
  printf("5. EXIT\n\n");
}

void searchWord(BTA*);
void addWord(BTA*);
void updateWord(BTA*);
void deleteWord(BTA*);



int main(int argc, char** argv){

  if (argc != 2){
    printf("There should be 2 arguments:\n");
    printf("1. Executed file.\n");
    printf("2. Btree file.\n");
    return 0;
  }

  
  BTA* btfile;
  btinit();
  btfile = btopn(argv[1], 0, FALSE);
  if(btfile == NULL){
    printf("Cannot generate Btree!\n");
    return 0;
  }
  
  int choice;

  do{
    MENU();
    printf("Choice: ");
    scanf("%d", &choice);
    getchar();

    switch (choice) {
    case 1:   //ADD NEW WORD
            addWord(btfile);
      break;
    case 2:  // DELETE
      deleteWord(btfile);
      break;
    case 3:   //MODIFY
      updateWord(btfile);
      break;
    case 4:   //SEARCH
      searchWord(btfile);
      break;
      
    case 5:   //EXIT
      break;
      
    default:
      printf("Invalid value: %d\n", choice);
      break;
    }
    
  }while(choice != 5);
  
  btcls(btfile);
  return 0;
}


void searchWord(BTA* btfile){
  char word[30];
  char meaning[50];
  int rsize;
  printf("\nWord: ");
  scanf("%[^\n]s", word);
  getchar();
  if(btsel(btfile, word, meaning, 100, &rsize) == 0){
    meaning[rsize-1] = '\0';
    printf("\n%-30s%s\n", "WORD", "DEFINITION");
    printf("%-30s%s\n", word, meaning);
  }
  else printf("Cannot find the word: \"%s\"\n", word);
}

void addWord(BTA* btfile){
  char word[30];
  char meaning[50];
  int flag = 0;
  int rsize;

  printf("\nWord: ");
  scanf("%[^\n]s", word);
  getchar();
  printf("Definition: ");
  scanf("%[^\n]s", meaning);
  getchar();

  flag = btins(btfile, strdup(word), strdup(meaning), strlen(meaning));
  if(flag == 0){
    printf("ADDING SUCCESSFULLY\n");
  }
  else if (flag == QDUP){
    printf("The word has already existed!\n");
    btsel(btfile, word, meaning, 100, &rsize);
    printf("\n%-30s%s\n", "WORD", "DEFINITON");
    printf("%-30s%s\n", word, meaning);
  }
}

void deleteWord(BTA* btfile){
  char word[30];
  
  printf("\nWord: ");
  scanf("%[^\n]s", word);
  getchar();

  if(btdel(btfile, word) == 0)
    printf("DELETING SUCCESSFULLY!\n");
  else printf("Can not find the word: \"%s\"\n", word);
}

void updateWord(BTA* btfile){
 char word[30];
  char meaning[50];
  int flag = 0;
  int rsize;

  printf("\nWord: ");
  scanf("%[^\n]s", word);
  getchar();
  
  if(btsel(btfile, word, meaning, 100, &rsize) != 0){
    printf("Can not find the  word: \"%s\"\n", word);
  }
  else{
    printf("ORIGINAL VERSION:\n");
    printf("\n%-30s%s\n", "WORD", "DEFINITON");
    printf("%-30s%s\n", word, meaning);
    
    printf("\nNew Definition: ");
    scanf("%[^\n]s", meaning);
    getchar();

    btupd(btfile, NULL, strdup(meaning), strlen(meaning)*sizeof(char));
    printf("\nUPDATING SUCCESSFULLY!\n");
    printf("UPDATED VERSION:\n");
    printf("\n%-30s%s\n", "WORD", "DEFINITION");
    printf("%-30s%s\n\n", word, meaning);
  }
  
}
