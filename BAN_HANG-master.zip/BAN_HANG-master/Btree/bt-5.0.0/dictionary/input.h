extern void getchar_ChangeMode();
extern void getchar_RestoreMode();
