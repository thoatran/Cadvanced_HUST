#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "btree.h"
#include <time.h>


char* createDefinition(char* word){
  char* meaning = (char*) malloc((strlen(word) + 50) * sizeof(char));
  strcat(meaning, word);
  strcat(meaning, "'s definiton");
  return meaning;
}

void readFile(FILE* f, BTA* btfile){
  int i = 0;
  char word[256];
  char* meaning;
  while((fgets(word,256, f)) != NULL){
    if (word[0] < 97)
        word[0] = word[0] + 32; 
    word[strlen(word)-1] = '\0';
    meaning = createDefinition(word);
    
    btins(btfile, strdup(word), meaning, strlen(meaning)*sizeof(char));
  }
   
}


int main(int argc, char** argv){
  
  if (argc != 2){
    printf("There should be 2 arguments:\n");
    printf("1. Executed file.\n");
    printf("2. Dictionary file.txt.\n");
    return 0;
  }

  char* file = argv[1];
  FILE* f;  
  if((f = fopen(file, "r")) == NULL){
    printf("%s does not exists!\n", file);
    return 0;
  }


  BTA* btfile;
  btinit();
  btfile = btcrt("dict_db", 0, FALSE);
  readFile(f, btfile);
  
  btcls(btfile);
  return 0;
}

